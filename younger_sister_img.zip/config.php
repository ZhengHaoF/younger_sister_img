<?php 
	header("Content-type: text/html; charset=utf-8");
	$MySqlHost = "localhost";
	$MySqlUser = "root";
	$MySqlPwd = "";
	$MySqlDatabaseName = "all_img_praise";
